﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMover : MonoBehaviour
{
    private GameObject player;
    public GameObject explosion;
    public float downSpeed;
    public int hp;
    public string moveStyle;
    public GameObject shot;
    public GameObject laser;
    private Rigidbody2D rb;
    private float deltaX;
    private float deltaY;
    private float angle;
    void Start()
    {
        player = GameObject.Find("Player");
        downSpeed = -downSpeed;
        rb = this.GetComponent<Rigidbody2D>();
        switch (moveStyle)
        {
            case "stationary":
                StartCoroutine(stationary());
                break;
            case "turr":
                StartCoroutine(turr());
                break;
            case "random":
                StartCoroutine(random());
                break;
            case "leftSwing":
                StartCoroutine(leftSwing());
                break;
            case "rightSwing":
                StartCoroutine(rightSwing());
                break;
            case "leftDiagonal":
                StartCoroutine(leftDiagonal());
                break;
            case "rightDiagonal":
                StartCoroutine(rightDiagonal());
                break;
            case "leftRightStop":
                StartCoroutine(leftRightStop());
                break;
            case "leftRight":
                StartCoroutine(leftRight());
                break;
            case "zigZag":
                StartCoroutine(zigZag());
                break;
            case "boss":
                StartCoroutine(bossMove());
                StartCoroutine(bossAttack());   
                break;
        }
    }

    void FixedUpdate() {
        if (hp <= 0) {
            Instantiate(explosion, this.transform.position, this.transform.rotation);
            Destroy(this.gameObject);
        }
        deltaX= this.transform.position.x - player.transform.position.x;
        deltaY = this.transform.position.y - player.transform.position.y;
        angle = Mathf.Atan2(deltaX, deltaY) / Mathf.PI * 180f;
        
    }
    private IEnumerator stationary()
    {
        rb.velocity = new Vector2(0f, downSpeed);
        while (true)
        {
            yield return new WaitForSeconds(2);
            Instantiate(shot, this.transform.position, this.transform.rotation);
        }
    }
    private IEnumerator turr()
    {
        //http://answers.unity3d.com/questions/628553/instantiate-projectile-towards-player-regardless-o.html
        rb.velocity = new Vector2(0f, downSpeed);
        while (true)
        {
            yield return new WaitForSeconds(2);
            Instantiate(shot, this.transform.position, Quaternion.Euler(new Vector3(angle, angle, angle)));
        }
    }
    private IEnumerator random()
    {
        rb.velocity = new Vector2(Random.Range(-5f, 5f), downSpeed+ Random.Range(-2f, 2f));
        while (true)
        {
            yield return new WaitForSeconds(2);
            Instantiate(shot, this.transform.position, this.transform.rotation);
        }
    }

    private IEnumerator leftSwing()
    {
        rb.velocity = new Vector2(0f, downSpeed);
        yield return new WaitForSeconds(2);
        Instantiate(shot);
        rb.velocity = new Vector2(-1f, downSpeed);
        yield return new WaitForSeconds(2);
        Instantiate(shot);
        rb.velocity = new Vector2(0f, downSpeed);
        while (true)
        {
            yield return new WaitForSeconds(2);
            Instantiate(shot,this.transform.position,this.transform.rotation);
        }
    }

    private IEnumerator rightSwing()
    {
        rb.velocity = new Vector2(0f, downSpeed);
        yield return new WaitForSeconds(2);
        Instantiate(shot);
        rb.velocity = new Vector2(1f, downSpeed);
        yield return new WaitForSeconds(2);
        Instantiate(shot);
        rb.velocity = new Vector2(0f, downSpeed);
        while (true)
        {
            yield return new WaitForSeconds(2);
            Instantiate(shot, this.transform.position, this.transform.rotation);
        }
    }
    private IEnumerator leftDiagonal()
    {
        float horizontal = downSpeed;
        rb.velocity = new Vector2(horizontal, downSpeed);
        while (true)
        {
            yield return new WaitForSeconds(2);
            Instantiate(shot, this.transform.position, this.transform.rotation);
        }
    }
    private IEnumerator rightDiagonal()
    {
        float horizontal = -downSpeed;
        rb.velocity = new Vector2(horizontal, downSpeed);
        while (true)
        {
            yield return new WaitForSeconds(2);
            Instantiate(shot, this.transform.position, this.transform.rotation);
        }
    }

    private IEnumerator leftRightStop()
    {
        rb.velocity = new Vector2(0, downSpeed);
        yield return new WaitForSeconds(2);
        for (int i = 0; i < 3; i++)
        {
            rb.velocity = new Vector2(-1f, 0);
            yield return new WaitForSeconds(1);
            Instantiate(shot, this.transform.position, this.transform.rotation);
            rb.velocity = new Vector2(1f, 0);
            yield return new WaitForSeconds(2);
            Instantiate(shot, this.transform.position, this.transform.rotation);
            rb.velocity = new Vector2(-1f, 0);
            yield return new WaitForSeconds(1);
        }
        rb.velocity = new Vector2(0, downSpeed);
    }

    private IEnumerator leftRight()
    {
        while (true)
        {
            rb.velocity = new Vector2(-1f, downSpeed);
            yield return new WaitForSeconds(2);
            Instantiate(shot);
            rb.velocity = new Vector2(1f, 0);
            yield return new WaitForSeconds(2);
            Instantiate(shot, this.transform.position, this.transform.rotation);
        }
    }

    private IEnumerator zigZag()
    {
        while (true)
        {
                rb.velocity = new Vector2(-1f, downSpeed);
                yield return new WaitForSeconds(1);
                Instantiate(shot, this.transform.position, this.transform.rotation);
                rb.velocity = new Vector2(1f, downSpeed);
                yield return new WaitForSeconds(2);
                Instantiate(shot, this.transform.position, this.transform.rotation);
                rb.velocity = new Vector2(-1f, downSpeed);
                yield return new WaitForSeconds(1);

        }
    }
    private IEnumerator bossMove()
    {
        rb.velocity = new Vector2(0, downSpeed);
        yield return new WaitForSeconds(2);
        while (true)
        {
            rb.velocity = new Vector2(-1f, 0);
            yield return new WaitForSeconds(2);
            rb.velocity = new Vector2(1f, 0);
            yield return new WaitForSeconds(2);
        }
    }
    private IEnumerator bossAttack() {
        float xDelta=0f;
        float yDelta=0f;
        while (hp < 50)
        {
            for (int i = 0; i < 50; i++)
            {
                Instantiate(shot, this.transform.position, Quaternion.Euler(0, 0, Time.deltaTime));
                yield return new WaitForSeconds(0.1f);
            }
            Instantiate(laser);
            yield return new WaitForSeconds(5f);
            for (int i = 0; i < 5; i++)
            {
                xDelta = this.transform.position.x - player.transform.position.x;
                yDelta = this.transform.position.y - player.transform.position.y;
                if (yDelta == 0) yDelta = 0.01f;
                Instantiate(shot, this.transform.position, Quaternion.Euler(0, 0, Mathf.Atan(xDelta / yDelta)));
                Instantiate(shot, this.transform.position, Quaternion.Euler(0, 0, Mathf.Atan(xDelta / yDelta) - 2));
                Instantiate(shot, this.transform.position, Quaternion.Euler(0, 0, Mathf.Atan(xDelta / yDelta) + 2));
                yield return new WaitForSeconds(0.5f);
            }
        }
        while (hp < 50)
        {
            for (int i = 0; i < 100; i++)
            {
                Instantiate(shot, this.transform.position, Quaternion.Euler(0, 0, Time.deltaTime));
                yield return new WaitForSeconds(0.05f);
            }
            xDelta = this.transform.position.x - player.transform.position.x;
            yDelta = this.transform.position.y - player.transform.position.y;
            if (yDelta == 0) yDelta = 0.01f;
            Instantiate(laser, this.transform.position, Quaternion.Euler(0, 0, Mathf.Atan(xDelta / yDelta) - 10));
            Instantiate(laser, this.transform.position, Quaternion.Euler(0, 0, Mathf.Atan(xDelta / yDelta) + 10));
            for (int i = 0; i < 5; i++)
            {
                Instantiate(shot, this.transform.position, Quaternion.Euler(0, 0, Mathf.Atan(xDelta / yDelta)));
                yield return new WaitForSeconds(1f);
            }
            for (int i = 0; i < 5; i++)
            {
                xDelta = this.transform.position.x - player.transform.position.x;
                yDelta = this.transform.position.y - player.transform.position.y;
                if (yDelta == 0) yDelta = 0.01f;
                Instantiate(shot, this.transform.position, Quaternion.Euler(0, 0, Mathf.Atan(xDelta / yDelta)));
                Instantiate(shot, this.transform.position, Quaternion.Euler(0, 0, Mathf.Atan(xDelta / yDelta) - 2));
                Instantiate(shot, this.transform.position, Quaternion.Euler(0, 0, Mathf.Atan(xDelta / yDelta) + 2));
                Instantiate(shot, this.transform.position, Quaternion.Euler(0, 0, Mathf.Atan(xDelta / yDelta) - 4));
                Instantiate(shot, this.transform.position, Quaternion.Euler(0, 0, Mathf.Atan(xDelta / yDelta) + 4));
                Instantiate(shot, this.transform.position, Quaternion.Euler(0, 0, Mathf.Atan(xDelta / yDelta) - 6));
                Instantiate(shot, this.transform.position, Quaternion.Euler(0, 0, Mathf.Atan(xDelta / yDelta) + 6));
                yield return new WaitForSeconds(0.5f);
            }
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.name == "player")
        {
            Destroy(other.gameObject);
        }
        if (other.gameObject.name == "playerBullet(Clone)")
        {
            hp--;
            Destroy(other.gameObject);
        }
        if (other.gameObject.name == "playerBulletTwo(Clone)")
        {
            hp-=2;
            Destroy(other.gameObject);
        }
        if (other.gameObject.name == "playerBulletThree(Clone)")
        {
            hp-=3;
            Destroy(other.gameObject);
        }
    }
}