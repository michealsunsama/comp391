﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class GameController : MonoBehaviour {
    public GameObject EnemyDown;
    public GameObject EnemyZigZag;
    public GameObject EnemyLeftRightDown;
    void Start () {

        StartCoroutine(SpawnWaves());
	}

	void Update () {

	}

    IEnumerator SpawnWaves()
    {
        Instantiate(EnemyDown,this.t)
        yield return new WaitForSeconds(2);    
    }

}
