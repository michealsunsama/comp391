﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class topBoundaryDestroyer : MonoBehaviour {
    public GameObject explosion;
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.name == "playerBullet(Clone)")
        {
            Destroy(other.gameObject);

        }
        if (other.gameObject.name == "Player")
        {
            Instantiate(explosion, this.transform.position, this.transform.rotation);
            Destroy(other.gameObject);
        }
    }
}
