﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class GameController : MonoBehaviour {
    public GameObject EnemyDown;
    public GameObject EnemyZigZag;
    public GameObject EnemyLeftRightDown;
    public GameObject EnemyRD;
    public GameObject EnemyLD;
    public GameObject EnemyTurr;
    void Start () {

        StartCoroutine(SpawnWaves());
	}

	void Update () {

	}

    IEnumerator SpawnWaves()
    {
        //wave 1
        Instantiate(EnemyDown,new Vector3(5f,6f,0), this.transform.rotation);
        yield return new WaitForSeconds(3);
        Instantiate(EnemyDown, new Vector3(-5f, 6f, 0), this.transform.rotation);
        yield return new WaitForSeconds(1);
        Instantiate(EnemyDown, new Vector3(-5f, 6f, 0), this.transform.rotation);
        yield return new WaitForSeconds(3);
        Instantiate(EnemyLeftRightDown, new Vector3(-4f, 6f, 0), this.transform.rotation);
        Instantiate(EnemyLeftRightDown, new Vector3(4f, 6f, 0), this.transform.rotation);
        yield return new WaitForSeconds(13);
        Instantiate(EnemyZigZag, new Vector3(2.5f, 6f, 0), this.transform.rotation);
        yield return new WaitForSeconds(1);
        Instantiate(EnemyZigZag, new Vector3(2.5f, 6f, 0), this.transform.rotation);
        yield return new WaitForSeconds(1);
        Instantiate(EnemyZigZag, new Vector3(2.5f, 6f, 0), this.transform.rotation);
        yield return new WaitForSeconds(1);
        Instantiate(EnemyZigZag, new Vector3(2.5f, 6f, 0), this.transform.rotation);
        yield return new WaitForSeconds(1);
        Instantiate(EnemyZigZag, new Vector3(2.5f, 6f, 0), this.transform.rotation);
        yield return new WaitForSeconds(1);
        //wave 2
        Instantiate(EnemyRD, new Vector3(-3f, 6f, 0), this.transform.rotation);
        yield return new WaitForSeconds(1);
        Instantiate(EnemyRD, new Vector3(-3.5f, 6f, 0), this.transform.rotation);
        yield return new WaitForSeconds(3);
        Instantiate(EnemyLD, new Vector3(2f, 6f, 0), this.transform.rotation);
        yield return new WaitForSeconds(1);
        Instantiate(EnemyLD, new Vector3(2.5f, 6f, 0), this.transform.rotation);
        yield return new WaitForSeconds(1);
        Instantiate(EnemyLD, new Vector3(3f, 6f, 0), this.transform.rotation);
        yield return new WaitForSeconds(1);
        Instantiate(EnemyLD, new Vector3(3.5f, 6f, 0), this.transform.rotation);
        yield return new WaitForSeconds(1);
        Instantiate(EnemyLD, new Vector3(4f, 6f, 0), this.transform.rotation);
        yield return new WaitForSeconds(4);
        Instantiate(EnemyTurr, new Vector3(-4f, 6f, 0), this.transform.rotation);
        Instantiate(EnemyTurr, new Vector3(4f, 6f, 0), this.transform.rotation);
        yield return new WaitForSeconds(4);
        Instantiate(EnemyDown, new Vector3(-4f, 6f, 0), this.transform.rotation);
        Instantiate(EnemyDown, new Vector3(4f, 6f, 0), this.transform.rotation);
        yield return new WaitForSeconds(1);
        Instantiate(EnemyDown, new Vector3(-2.5f, 6f, 0), this.transform.rotation);
        Instantiate(EnemyDown, new Vector3(2.5f, 6f, 0), this.transform.rotation);
        yield return new WaitForSeconds(1);
        Instantiate(EnemyDown, new Vector3(-1f, 6f, 0), this.transform.rotation);
        Instantiate(EnemyDown, new Vector3(1f, 6f, 0), this.transform.rotation);
        //wave 3
    }

}
